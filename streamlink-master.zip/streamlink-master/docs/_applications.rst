:orphan:


.. raw:: html

    <style>
        .rst-content table.field-list td {
            padding-top: 8px;
        }
        i.fab.fa-fw {
            font-size: 1.333em;
        }
    </style>

.. |Windows| raw:: html

    <i class="fab fa-fw fa-windows"></i>

.. |MacOS| raw:: html

    <i class="fab fa-fw fa-apple"></i>

.. |Linux| raw:: html

    <i class="fab fa-fw fa-linux"></i>
