{changelog}

## Installation

See the detailed [installation instructions](https://streamlink.github.io/install.html) on Streamlink's website.

## Supporting Streamlink

If you think that this application is helpful, please consider supporting the maintainers by [donating via the Open collective](https://opencollective.com/streamlink). Not only becoming a backer, but also a sponsor for the (open source) project.


{gitlog}
